<?php
// footer.php
?>
</main>
<footer class="center">
    <p>&copy; <?= date('Y') ?> Widget Store</p>
</footer>
</body>

</html>